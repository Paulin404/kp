const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* : Vrau ×͜×
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
──────────────────

*VOCE É UM MEMBRO PREMIUM* 💸`
}
exports.cekvip = cekvip

const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Inserir o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/559885018147 ou digite *${prefix}owner*_

*NOTA*

*Grupo do Papai Vrau ×͜× :*
_Em Breve_ `
}
exports.daftarvip = daftarvip

const help1 = (prefix) => {

	return `
┣━━━━°❀ ❬ *CRIAR* ❭ ❀°━━━━┓
┃
┣⊱❥ *xd*
┣⊱❥ *pinterest*
┣⊱❥ *anjing*
┣⊱❥ *loli2*
┣⊱❥ *anime*
┣⊱❥ *wolflogo2 <texto | texto>*
┣⊱❥ *quotemaker <tx | wtrmk | tema>*
┣⊱❥ *galaxtext*
┣⊱❥ *textdark*
┣⊱❥ *textblue*
┣⊱❥ *lovemake*
┣⊱❥ *stiltext*
┣⊱❥ *ninjalogo*
┣⊱❥ *party*
┣⊱❥ *rtext*
┣⊱❥ *water*
┣⊱❥ *lionlogo <texto | texto>*
┣⊱❥ *textscreen*
┣⊱❥ *text3d*
┣⊱❥ *epep*
┣⊱❥ *marvelogo <texto | texto>*
┣⊱❥ *snow <texto | texto>*
┣⊱❥ *firetext*

"Alguns comandos off devido a quedas de apikey."

════════════════════
* ✞ঔVrau 𝒐͢𝒇𝒄ꪶ↷💸*
*Digite dono para mais info*
════════════════════`
}
exports.help1 = help1



const apkpremium = (prefix) => {

	return `

APKS PREMIUM BY TrashфDkOFC:

🔥Netguard pro🔥
http://www.mediafire.com/file/rxri0mzbnm7vl8z/NetGuard-Pro.apk/file


🔥Screen mirror pro🔥
http://www.mediafire.com/file/b3txo9fasxoo2jp/Scree+Mirror+pro.apk/file


🔥Faketweets Premium 🔥
http://www.mediafire.com/file/lfge1ahgueuaq46/fake+tweets+apk+premium+😔✊.apk/file


🔥Retro music Premium🔥
http://www.mediafire.com/file/30w58g9d578xox8/Retro_Music-Premium.apk/file


🔥KWGT widget Premium🔥
http://www.mediafire.com/file/41551tsfpgsabsg/KWGT_WIDGET_PRO_Premium_Apkss+(1).apk/file


🔥3d wallpaper Premium 🔥
http://www.mediafire.com/file/ajg7evvaa2w77pl/3D-Wallpaper-Premium.apk/file


🔥SnapTube Premium🔥
http://www.mediafire.com/file/tt5icyismqmlh08/SNAPTUBE-VIP-PREMIUM.apk/file


🔥Touch retouch Premium🔥
http://www.mediafire.com/file/mtw1scy2wqgny7l/touch-retouch-Premium.apk/file


🔥CrunchyrollPremium🔥
http://www.mediafire.com/file/fesu5oxbyxmpja3/Crunchyroll-Premium.apk/file


🔥Reface app Premium🔥
http://www.mediafire.com/file/7yl0uiz8r9bx8um/REFACE-APP-PREMIUM.apk/file


🔥Deezer Premium🔥
http://www.mediafire.com/file/z6rynjf7yrfhxik/Deezer_6.2.14.1_Mod_arm7_androidtunado.com.apk/file


🔥Youtube Premium - Sem anúncios🔥
http://www.mediafire.com/file/hbyu9ht3iqhzgo9/YouTube+Vanced+15.43.32+(com.vanced.android.youtube).apk/file


🔥Pixel Lab Premium🔥
http://www.mediafire.com/file/tm3wl3qs8oj3h7s/PixelLab+1.9.9+(com.imaginstudio.imagetools.pixellab).apk/file


🔥Ps Touch Premium🔥
http://www.mediafire.com/file/h3ul4l7w2g5ymjr/Ps+Touch+Plus.apk/file


🔥Sportfy premium🔥
http://www.mediafire.com/file/a43h5pthbxlx3z7/Spotify+v8.5.71.723+build+62919622.apk/file


🔥Insta pro (Premium)🔥
http://www.mediafire.com/file/fbprzchi6wp6mix/Insta+Pro+atualizado.apk/file


🔥Wallcraft papel de parede premium🔥
http://www.mediafire.com/file/mjqpws2v7qzpwhx/Wallcraft-PREMIUM.apk/file


🔥Power director premium🔥
http://www.mediafire.com/file/l876wmh3yv7vb7a/PowerDirector-v5.4.2-Unlocked.apk/file


🔥AirBrush premium🔥
http://www.mediafire.com/file/nrvmsmnyk259n6v/AirBrush-Premium-4_8_0.apk/file


🔥Youtube music premium🔥
http://www.mediafire.com/file/xkjkh5zqy623gpt/YouTube+Music+4.07.51+(com.vanced.android.apps.youtube.music).apk/file
`

}

exports.apkpremium = apkpremium
